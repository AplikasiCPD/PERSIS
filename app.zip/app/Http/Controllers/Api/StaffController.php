<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\StaffResource;
use App\Http\Traits\CanLoadRelationships;
use App\Models\Staff;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;

class StaffController extends Controller
{
    use CanLoadRelationships, AuthorizesRequests;

    private array $relations = ['jantina', 'bangsa', 'agama', 'jawatan', 'gred', 'bahagian', 'cawangan', 'seksyen', 'status', 'gelaran'];

    /**
     * Display a listing of the resource.
     */

    public function __construct()
    {
        // Option 1: Require auth for all except index and show
        $this->middleware('auth:sanctum')->except(['index', 'show']);
        
        // Option 2: Require auth only for specific methods
        // $this->middleware('auth:sanctum')->only(['store', 'update', 'destroy']);
        
        // Option 3: No middleware - all public (policy still enforces auth on create/update/delete)
        // (comment out the middleware line above)
        
        $this->authorizeResource(Staff::class, 'staff');
    }


    public function index()
    {
        $query = $this->loadRelationships(Staff::query());

        return StaffResource::collection($query->paginate(15));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $staff = Staff::create([
            ...$request->validate([
                'staff_id' => 'required|string|max:255',
                'nama' => 'nullable|string',
                'no_kp' => 'required|string|max:255',
                'no_tel' => 'required|string|max:255',
                'emel' => 'required|string|max:50',
                'kod_jantina' => 'required|string|max:255',
                'kod_bangsa' => 'required|string|max:255',
                'kod_agama' => 'required|string|max:255',
                'kod_lantikan' => 'required|string|max:255',
                'tarikh_lantikan' => 'required|date|after:tarikh_lahir',
                'tarikh_masuk' => 'required|date|after:tarikh_lahir',
                'tarikh_sah' => 'required|date|after:tarikh_masuk',
                'tarikh_gred_semasa' => 'required|date|after:tarikh_masuk',
                'tarikh_penempatan_semasa' => 'required|date|after:tarikh_masuk',
                'kod_rekod' => 'required|string|max:255',
                'tarikh_rekod' => 'required|date',
                'catatan_rekod' => 'required|string|max:255',
                'kod_jawatan_semasa' => 'required|string|max:255',
                'kod_gred_semasa' => 'required|string|max:255',
                'status_gred' => 'required|string|max:255',
                'kod_bhgn_semasa' => 'required|string|max:255',
                'kod_caw_semasa' => 'required|string|max:255',
                'kod_seksyen_semasa' => 'required|string|max:255',
                'umur_bersara' => 'required|integer',
                'catatan' => 'nullable|string',
                'user_level' => 'required|integer',
                'speed_dial' => 'nullable|string',
                'connection' => 'nullable|string',
                'tarikh_lahir' => 'required|date',
                'tarikh_dinaikkan_pangkat' => 'nullable|date|after:tarikh_masuk',
                'tarikh_pencen' => 'required|date|after:tarikh_masuk',
                'gaji_pokok' => 'required|numeric',
                'bulan_naik_gaji' => 'required|integer',
                'status_code' => 'required|string|max:255',
                'staff_location' => 'nullable|string',
                'kod_gelaran_semasa' => 'required|string|max:255',
            ]),
        ]);

        return new StaffResource($this->loadRelationships($staff));
    }

    /**
     * Display the specified resource.
     */
    public function show(Staff $staff)
    {
        $staff = $this->loadRelationships($staff);

        return new StaffResource($staff);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Staff $staff)
    {
        $staff->update(
            $request->validate([
                'staff_id' => 'sometimes|string|max:255',
                'nama' => 'sometimes|string',
                'no_kp' => 'sometimes|string|max:255',
                'no_tel' => 'sometimes|string|max:255',
                'emel' => 'sometimes|string|max:50',
                'kod_jantina' => 'sometimes|string|max:255',
                'kod_bangsa' => 'sometimes|string|max:255',
                'kod_agama' => 'sometimes|string|max:255',
                'kod_lantikan' => 'sometimes|string|max:255',
                'tarikh_lantikan' => 'sometimes|date|after:tarikh_lahir',
                'tarikh_masuk' => 'sometimes|date|after:tarikh_lahir',
                'tarikh_sah' => 'sometimes|date|after:tarikh_masuk',
                'tarikh_gred_semasa' => 'sometimes|date|after:tarikh_masuk',
                'tarikh_penempatan_semasa' => 'sometimes|date|after:tarikh_masuk',
                'kod_rekod' => 'sometimes|string|max:255',
                'tarikh_rekod' => 'sometimes|date',
                'catatan_rekod' => 'sometimes|string|max:255',
                'kod_jawatan_semasa' => 'sometimes|string|max:255',
                'kod_gred_semasa' => 'sometimes|string|max:255',
                'status_gred' => 'sometimes|string|max:255',
                'kod_bhgn_semasa' => 'sometimes|string|max:255',
                'kod_caw_semasa' => 'sometimes|string|max:255',
                'kod_seksyen_semasa' => 'sometimes|string|max:255',
                'umur_bersara' => 'sometimes|integer',
                'catatan' => 'sometimes|string',
                'user_level' => 'sometimes|integer',
                'speed_dial' => 'sometimes|string',
                'connection' => 'sometimes|string',
                'tarikh_lahir' => 'sometimes|date',
                'tarikh_dinaikkan_pangkat' => 'sometimes|date|after:tarikh_masuk',
                'tarikh_pencen' => 'sometimes|date|after:tarikh_masuk',
                'gaji_pokok' => 'sometimes|numeric',
                'bulan_naik_gaji' => 'sometimes|integer',
                'status_code' => 'sometimes|string|max:255',
                'staff_location' => 'sometimes|string',
                'kod_gelaran_semasa' => 'sometimes|string|max:255',
            ])
        );

        return new StaffResource($this->loadRelationships($staff));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Staff $staff)
    {
        $staff->delete();
        return response(status: 204);
    }
}
